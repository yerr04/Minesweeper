Name: Michael Mwaura
Section: 22987
UFL email: mwaura.michael@ufl.edu
System: Windows
Compiler: Microsoft Visual C++ Compiler
SFML version: SFML-2.5.1-windows-vc15-64-bit
IDE: Visual Studio 2022
Other notes: Imma be real with whoever is grading this, I ran out of time and could not get the timer (and subsequently, the user adding to leaderboard) to work) I know that is a few points off and I have come to terms with that. Have a wonderful day!