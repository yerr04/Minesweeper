#pragma once
#include <vector>
#include <SFML/Graphics.hpp>

int Leaderboard(int width, int height);

